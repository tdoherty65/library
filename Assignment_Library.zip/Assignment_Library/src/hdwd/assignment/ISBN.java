package hdwd.assignment;

public class ISBN {

	String isbn;


	public ISBN (String is) {
		isbn = is;
	}

	public String toString() {
		return "[isbn:" + isbn + "]";
	}
}


